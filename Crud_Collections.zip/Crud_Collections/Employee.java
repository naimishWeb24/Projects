package practice;

import java.util.UUID;

public class Employee {
	UUID EmployeeId;
	String EmployeeName;
	String EmployeeSkills;
	int EmployeeAge;
	double EmployeeSalary;
	String Date;
	
	public Employee(UUID EmployeeId,String EmployeeName,String EmployeeSkills,int EmployeeAge,double EmployeeSalary,String Date)
	{
		this.EmployeeId=EmployeeId;
		this.EmployeeName=EmployeeName;
		this.EmployeeSkills=EmployeeSkills;
		this.EmployeeAge=EmployeeAge;
		this.EmployeeSalary=EmployeeSalary;
		this.Date=Date;
				
	}
	
	

	public Employee(String EmployeeName2, String EmployeeSkills2, int EmployeeAge2, double EmployeeSalary2, String Date2) {
		this.EmployeeName=EmployeeName2;
		this.EmployeeSkills=EmployeeSkills2;
		this.EmployeeAge=EmployeeAge2;
		this.EmployeeSalary=EmployeeSalary2;
		this.Date=Date2;
	}



	@Override
	public String toString() {
		return "Employee [EmployeeName=" + EmployeeName + ", EmployeeSkills=" + EmployeeSkills + ", EmployeeAge=" + EmployeeAge + ", EmployeeSalary=" + EmployeeSalary
				+ ", Date=" + Date + "]";
		
		
	}



	public UUID getEmployeeId()
	{
		return EmployeeId;
	}
	
	public String getEmployeeName()
	{
		return EmployeeName;
	}
	
	public String getEmployeeSkills()
	{
		return EmployeeSkills;
	}
	
	public int getEmployeeAge()
	{
		return EmployeeAge;
	}
	
	public double getEmployeeSalary()
	{
		return EmployeeSalary;
	}
	
	public String getDate()
	{
		return Date;
	}
	
	
	
	
}
