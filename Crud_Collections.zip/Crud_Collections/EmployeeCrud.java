package practice;
import java.util.UUID;
import java.text.SimpleDateFormat;
import java.util.*;

public class EmployeeCrud {

	private static ArrayList<Employee> arrayList=new ArrayList<>();
	
	// insert Operation
	public static void insert() {
		Scanner scanner = new Scanner(System.in);
		UUID uid = UUID.randomUUID();
		UUID employeeId = uid;
		System.out.println("Enter Employee Name : ");
		String employeeName = scanner.next();													
		
		System.out.println("Enter Employee skills : ");
		String employeeSkills = scanner.next();
		
		// age Validation
		int employeeAge;
		do {
			System.out.println("Enter Employee age : ");
			while(!scanner.hasNextInt()) {
				System.out.println("Please enter a Valid Age (a number)  ");
				scanner.next();
			}
			employeeAge = scanner.nextInt();
		} while(!isValidAge(employeeAge));
		
		
		System.out.println("Enter Employee salary : ");
		double employeeSalary = scanner.nextDouble();
		
		
		String date;
		do {
			System.out.println("Enter Employee Joining date : ");
			date = scanner.next();
		
		} while (!isValidDate(date));
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		Date date2 = null;
		try 
		{
			date2 = dateFormat.parse(date);
		} catch(Exception e) {
			System.out.println("Enter valid Date !!");
			return;
		}
		
		// calling constructor for inserting the data
		Employee e = new Employee(employeeId,employeeName,employeeSkills,employeeAge,employeeSalary,date);
		arrayList.add(e);
	}
	
	// Date Validation
	private static boolean isValidDate(String date) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        dateFormat.setLenient(false);

        try {
            dateFormat.parse(date);
            return true;
        } catch (Exception e) {
            System.out.println("Invalid date format. Please enter the date in dd-MM-yyyy format.");
            return false;
        }
    }
	
	// Method to Validate Age
	private static boolean isValidAge(int EmployeeAge) {
		return EmployeeAge > 0 && EmployeeAge < 100;
	}
	
	// Displaying the data
	public static void display() {
		// if data not found then showing data is not found
		if (arrayList.isEmpty()) {
			System.out.print("No data found !!");
		} else {
			// Displaying the data
			System.out.println("Id"+" "+"name"+" "+"skills+"+"  "+"Age"+" "+"salary"+" "+"Joining date");
			for (int i = 0; i < arrayList.size(); i++) {
				Employee e = arrayList.get(i);
				System.out.println(i + "  " + e.toString());
			}
		}
	}
	
	// Delete Operation
	public static void delete() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter employee number you want delete : ");
		int number = scanner.nextInt();
		if ( arrayList.isEmpty() ) {
			System.out.println("List is empty !!");
			
		} else {
			for (int i = 0; i < arrayList.size(); i++) {
				Employee e = arrayList.get(i);
				
				if(i == number) {
					arrayList.remove(i);
					System.out.println("Employee Deleted succesfully !!");
					return;
				}
			}
		}
	}
	
	// Search Operation 
	public static void search() {
		Scanner scanner = new Scanner(System.in);
		
		// getting input from user for searching employee
		System.out.println("enter employee name you want Search: ");
		String employeeName = scanner.next();
		if(arrayList.isEmpty()) {
			System.out.println("List is empty !!");
			
		} else {
			for (int i = 0; i < arrayList.size(); i++) {
				Employee e = arrayList.get(i);
				
				if (e.getEmployeeName().equals(employeeName)) {
					System.out.println( i + "  " + e.toString());
					return;
				}
			}
		}
	}
	
	// Update operation
	public static void update() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter employee number you want update : "); 
		int num = scanner.nextInt();
		if(arrayList.isEmpty()) {
			System.out.println("List is empty !!");
			
		} else {
			for (int i = 0; i < arrayList.size(); i++) {
				Employee e = arrayList.get(i);
				
				if (i == num) {
					UUID uid = UUID.randomUUID();
					UUID employeeId = uid;
					
					System.out.println("Enter Employee Name : ");
					String employeeName = scanner.next();
					
					System.out.println("Enter Employee skills : ");
					String employeeSkills = scanner.next();
					
					int employeeAge;
					do {
						System.out.println("Enter Employee age : ");
						while (!scanner.hasNextInt()) {
							System.out.println("Please enter a Valid Age (a number)  ");
							scanner.next();
						}
						employeeAge = scanner.nextInt();
					} while(!isValidAge(employeeAge));
					
					System.out.println("Enter Employee salary : ");
					double employeeSalary = scanner.nextDouble();
					
					String date;
					do {
						System.out.println("Enter Employee Joining date : ");
						date = scanner.next();
					
					} while (!isValidDate(date));
					
					SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
					Date date2 = null;
					try {
						date2 = dateFormat.parse(date);
					} catch(Exception em) {
						System.out.println("Enter valid Date !!");
						return;
					}
					arrayList.set(i, new Employee(employeeId,employeeName,employeeSkills,employeeAge,employeeSalary,date));
					
					
					return;
				}
			}
		}
	}
	public static void sort (ArrayList<Employee> arrayList) {
		
		int n = arrayList.size();
		for (int i = 1; i < n; i++) {
				Employee  e = arrayList.get(i);
				int j = i - 1;
				
			while (j >= 0 && arrayList.get(j).EmployeeAge > e.EmployeeAge) {
				arrayList.set( j + 1 , arrayList.get(j));
				j = j-1;
			}
			arrayList.set( j+1, e);
			
		}
		
		for (int i = 0; i < arrayList.size(); i++) {
			Employee e=arrayList.get(i);		
			System.out.println(i + "  " + e.toString());
		}
		
	}
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
			EmployeeCrud employee = new EmployeeCrud();
		while(true) {
			System.out.println();
			System.out.println("1.insert");
			System.out.println("2.display");
			System.out.println("3.delete");
			System.out.println("4.update");
			System.out.println("5.sort");
			System.out.println("6.Search");
			
			
			System.out.println();
			System.out.println("Enter your Choice : ");
			int choice = scanner.nextInt();
			System.out.println();
			
				switch(choice) {
				
					case 1: employee.insert();
							break;	
							
					case 2: employee.display();
							break;
							
					case 3: employee.delete();
							break;
							
					case 4:	employee.update();
							break;
							
					case 5:	employee.sort(arrayList);
							break;
							
					case 6:	employee.search();
							break;
							
					default:System.out.println("Enter Valid Choice : ");
							break;
				}
				
			}	
	}
	
}
